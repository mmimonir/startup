<?php
/*
Plugin Name: Startup Plugin
Plugin URI: http://www.startup.com 
Description: This is a plugin for the Startup theme.
Author: Md Monirul Islam
Author URI: http://www.startup.com
Version: 1.0
 */
function startup_cpt()
{ // Slider Custom Post Type
    $labels = array(
        'name' => _x('Sliders', 'Post type general name', 'startup'),
        'singular_name' => _x('Slider', 'Post type singular name', 'startup'),
        'menu_name' => _x('Sliders', 'Admin Menu text', 'startup'),
        'name_admin_bar' => _x('Slider', 'Add New on Toolbar', 'startup'),
        'add_new' => __('Add New', 'slider'),
        'add_new_item' => __('Add New Slider', 'startup'),
        'new_item' => __('New Slider', 'startup'),
        'edit_item' => __('Edit Slider', 'startup'),
        'view_item' => __('View Slider', 'startup'),
        'all_items' => __('All Slider', 'startup'),
        'search_items' => __('Search Slider', 'startup'),
        'parent_item_colon' => __('Parent Slider:', 'startup'),
        'not_found' => __('No slider found.', 'startup'),
        'not_found_in_trash' => __('No slider found in Trash.', 'startup'),
        'featured_image' => _x('Slider Cover Image', 'Overrides the “Featured Image” phrase for this post type. Added in 4.3', 'startup'),
        'set_featured_image' => _x('Set slider image', 'Overrides the “Set featured image” phrase for this post type. Added in 4.3', 'startup'),
        'remove_featured_image' => _x('Remove sliver image', 'Overrides the “Remove featured image” phrase for this post type. Added in 4.3', 'startup'),
    );
    $args = array(
        'public' => true,
        'labels' => $labels,
        'menu_icon' => 'dashicons-book',

        'publicly_queryable' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'query_var' => true,
        'rewrite' => array('slug' => 'sliders'),
        'capability_type' => 'post',
        'has_archive' => false,
        'hierarchical' => false,
        'menu_position' => 20,
        'supports' => array('title', 'thumbnail', 'custom-fields', 'thumbnail'),
        // 'taxonomies' => array('category', 'post_tag'),
    );
    register_post_type('slider', $args);

    // Services Custom Post Type
    $labels = array(
        'name' => _x('Services', 'Post type general name', 'startup'),
        'singular_name' => _x('Service', 'Post type singular name', 'startup'),
        'menu_name' => _x('Services', 'Admin Menu text', 'startup'),
        'name_admin_bar' => _x('Service', 'Add New on Toolbar', 'startup'),
        'add_new' => __('Add New', 'slider'),
        'add_new_item' => __('Add New Service', 'startup'),
        'new_item' => __('New Service', 'startup'),
        'edit_item' => __('Edit Service', 'startup'),
        'view_item' => __('View Service', 'startup'),
        'all_items' => __('All Services', 'startup'),
        'search_items' => __('Search Services', 'startup'),
        'parent_item_colon' => __('Parent Services:', 'startup'),
        'not_found' => __('No services found.', 'startup'),
        'not_found_in_trash' => __('No services found in Trash.', 'startup'),
    );
    $args = array(
        'public' => true,
        'labels' => $labels,
        'menu_icon' => 'dashicons-book',
        'publicly_queryable' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'query_var' => true,
        'rewrite' => array('slug' => 'services'),
        'capability_type' => 'post',
        'has_archive' => false,
        'hierarchical' => false,
        'menu_position' => 20,
        'supports' => array('title', 'editor', 'custom-fields', 'thumbnail'),
    );
    register_post_type('services', $args);

    // Price Custom Post
    $labels = array(
        'name' => _x('Prices', 'Post type general name', 'startup'),
        'singular_name' => _x('Price', 'Post type singular name', 'startup'),
        'menu_name' => _x('Prices', 'Admin Menu text', 'startup'),
        'name_admin_bar' => _x('Price', 'Add New on Toolbar', 'startup'),
        'add_new' => __('Add New', 'slider'),
        'add_new_item' => __('Add New Price', 'startup'),
        'new_item' => __('New Price', 'startup'),
        'edit_item' => __('Edit Price', 'startup'),
        'view_item' => __('View Price', 'startup'),
        'all_items' => __('All Prices', 'startup'),
        'search_items' => __('Search Prices', 'startup'),
        'parent_item_colon' => __('Parent Prices:', 'startup'),
        'not_found' => __('No prices found.', 'startup'),
        'not_found_in_trash' => __('No prices found in Trash.', 'startup'),
    );
    $args = array(
        'public' => true,
        'labels' => $labels,
        'menu_icon' => 'dashicons-book',
        'publicly_queryable' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'query_var' => true,
        'rewrite' => array('slug' => 'price'),
        'capability_type' => 'post',
        'has_archive' => false,
        'hierarchical' => false,
        'menu_position' => 20,
        'supports' => array('title', 'custom-fields', 'thumbnail'),
    );
    register_post_type('price', $args);

    // Testimonials Custom Post
    $labels = array(
        'name' => _x('Testimonials', 'Post type general name', 'startup'),
        'singular_name' => _x('Testimonial', 'Post type singular name', 'startup'),
        'menu_name' => _x('Testimonials', 'Admin Menu text', 'startup'),
        'name_admin_bar' => _x('Testimonial', 'Add New on Toolbar', 'startup'),
        'add_new' => __('Add New', 'slider'),
        'add_new_item' => __('Add New Testimonial', 'startup'),
        'new_item' => __('New Testimonial', 'startup'),
        'edit_item' => __('Edit Testimonial', 'startup'),
        'view_item' => __('View Testimonial', 'startup'),
        'all_items' => __('All Testimonials', 'startup'),
        'search_items' => __('Search Testimonials', 'startup'),
        'parent_item_colon' => __('Parent Testimonials:', 'startup'),
        'not_found' => __('No testimonials found.', 'startup'),
        'not_found_in_trash' => __('No testimonials found in Trash.', 'startup'),
    );
    $args = array(
        'public' => true,
        'labels' => $labels,
        'menu_icon' => 'dashicons-book',
        'publicly_queryable' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'query_var' => true,
        'rewrite' => array('slug' => 'testimonial'),
        'capability_type' => 'post',
        'has_archive' => false,
        'hierarchical' => false,
        'menu_position' => 20,
        'supports' => array('title', 'custom-fields'),
    );
    register_post_type('testimonial', $args);

    // Teams Custom Post
    $labels = array(
        'name' => _x('Teams', 'Post type general name', 'startup'),
        'singular_name' => _x('Team', 'Post type singular name', 'startup'),
        'menu_name' => _x('Teams', 'Admin Menu text', 'startup'),
        'name_admin_bar' => _x('Team', 'Add New on Toolbar', 'startup'),
        'add_new' => __('Add New', 'slider'),
        'add_new_item' => __('Add New Team', 'startup'),
        'new_item' => __('New Team', 'startup'),
        'edit_item' => __('Edit Team', 'startup'),
        'view_item' => __('View Team', 'startup'),
        'all_items' => __('All Teams', 'startup'),
        'search_items' => __('Search Teams', 'startup'),
        'parent_item_colon' => __('Parent Teams:', 'startup'),
        'not_found' => __('No teams found.', 'startup'),
        'not_found_in_trash' => __('No teams found in Trash.', 'startup'),
    );
    $args = array(
        'public' => true,
        'labels' => $labels,
        'menu_icon' => 'dashicons-book',
        'publicly_queryable' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'query_var' => true,
        'rewrite' => array('slug' => 'team'),
        'capability_type' => 'post',
        'has_archive' => false,
        'hierarchical' => false,
        'menu_position' => 20,
        'supports' => array('title', 'custom-fields', 'thumbnail'),
    );
    register_post_type('team', $args);
}
add_action('init', 'startup_cpt');
